@extends('layouts.customer')



{{-- make no margin in banner (only this page) --}}
<style>
    .tg-innerpagebanner {
        margin-bottom: 0px !important;
    }
</style>





{{-- section --}}
@section('content')


{{-- banner --}}
<div class="tg-innerpagebanner">
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                <div class="tg-pagetitle">
                    <a href="{{ route('customer.home') }}" class="home-button-custom">
                        <i class="fa fa-arrow-circle-left"></i>Home</a>
                </div>
                <ol class="tg-breadcrumb">
                    <li><a href="#">Home</a></li>
                    <li><a href="#">Deals</a></li>
                    <li class="tg-active">Hardware Suppling</li>
                </ol>
            </div>
        </div>
    </div>
</div>
{{-- end banner --}}







{{-- main --}}
<main id="tg-main" class="tg-main tg-haslayout tg-paddingzero" style="background-color: black;">
    <div class="tg-serviceprovider tg-detailpage tg-serviceproviderdetail">

        <div id="tg-twocolumns" class="tg-twocolumns">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12 col-sm-7 col-md-12 col-lg-12 pull-left">
                        <div id="tg-content" class="tg-content">
                            <div class="tg-advertisement">
                                <!-- <img src="images/advertisement/img-01.png" alt="image description"></a> -->
                            </div>
                            <div class="tg-companyfeatures">
                                <div class="tg-companyfeaturebox tg-introduction">
                                    <div class="tg-companyfeaturetitle">
                                        <h3 class="text-white-f custom-pr-view-subheading">Description</h3>
                                    </div>
                                    <div class="tg-description">
                                        <p class="text-offwhite-f">Consectetur adipisicing elit sed do eiusmod tempor
                                            incididunt ut labore et dolore magna aliqua enim ad minimat quis nostrud
                                            exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat aute
                                            irure dolor reprehenderit in voluptate velit esse cillum dolore eu fugiat
                                            nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in
                                            culpa qui officia deserunt mollit anim id est laborum ut perspiciatis unde
                                            omnis iste natus error sit voluptatem accusantium doloremque laudantium
                                            totam rem aperiam ab illo inventore veritatis quasi architecto beatae vitae
                                            dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit
                                            aspernatur aut fugit sed quia consequuntur magni dolores eos qui ratione
                                            voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia
                                            dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi
                                            tempora incidunt ut labore et dolore magnam aliquam quaerat
                                            voluptatem.<br>Consectetur adipisicing elit sed do eiusmod tempor incididunt
                                            ut labore et dolore magna aliqua enim ad minimat quis nostrud exercitation
                                            ullamco laboris nisi ut aliquip ex ea commodo consequat aute irure dolor
                                            reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla
                                            pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui
                                            officia deserunt mollit anim id est laborum ut perspiciatis unde omnis iste
                                            natus error sit voluptatem accusantium doloremque laudantium totam rem
                                            aperiam ab illo inventore veritatis quasi architecto beatae vitae dicta sunt
                                            explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut fugit
                                            sed quia consequuntur magni dolores eos qui ratione voluptatem sequi
                                            nesciunt.</p>

                                    </div>
                                </div>
                                <div class="tg-companyfeaturebox tg-languages">
                                    <div class="tg-companyfeaturetitle">
                                        <div class="row align-items-end mb-2">
                                            <div class="col-6 text-left">
                                                <h3 class="text-white-f custom-pr-view-subheading">List of Items</h3>
                                            </div>

                                            <div class="col-6 text-right">
                                                <a href="javascript:void(0);" class="confirm-quotation-edit"
                                                    style="margin-left: 10px; background-color: indianred; border-color:indianred; color:white; padding: 8px 10px; font-weight: 500">
                                                    Deal Attachments<i class="fa fa-download ml-2"></i>
                                                </a>
                                            </div>

                                        </div>
                                    </div>
                                    <table class="table custom-pr-table">
                                        <tbody>

                                            <thead>
                                                <th>
                                                    Name
                                                </th>

                                                <th>
                                                    Category
                                                </th>

                                                <th class="text-center">
                                                    Item Type
                                                </th>

                                                <th class="text-center">
                                                    Minimum Quantity
                                                </th>

                                                <th class="text-center">
                                                    Price (AED)
                                                </th>

                                            </thead>
                                            <!-- tr -->
                                            <tr>
                                                <td>

                                                    <div class="tg-contentbox">
                                                        <!-- <a class="tg-tag tg-featuredtag" href="#"></a> -->
                                                        <div class="tg-title">
                                                            <h3><a href="#">Mouses and Keyboards</a></h3>
                                                        </div>
                                                        <span> </span>
                                                    </div>
                                                </td>

                                                <!-- category / subcategory -->
                                                <td><span>Computer > Hardware</span></td>




                                                <td class="valign-middle text-center">
                                                    <button disabled="" class="btn-sm btn-warning">Product</button>
                                                </td>


                                                <!-- quantity + measuringunit -->
                                                <td class="valign-middle text-center"><span class="text-black-f">100
                                                        Piece</span></td>


                                                <!-- price -->
                                                <td class="valign-middle text-center"><span
                                                        class="text-black-f">4,000</span></td>
                                            </tr>
                                            <!-- end table row -->



                                            <!-- tr -->
                                            <tr>
                                                <td>

                                                    <div class="tg-contentbox">
                                                        <!-- <a class="tg-tag tg-featuredtag" href="#"></a> -->
                                                        <div class="tg-title">
                                                            <h3><a href="#">PC Desktop Screen</a></h3>
                                                        </div>
                                                        <span> </span>
                                                    </div>
                                                </td>

                                                <!-- category / subcategory -->
                                                <td><span>Computer > Hardware</span></td>




                                                <td class="valign-middle text-center">
                                                    <button disabled="" class="btn-sm btn-warning">Product</button>
                                                </td>


                                                <!-- quantity + measuringunit -->
                                                <td class="valign-middle text-center"><span class="text-black-f">40
                                                        Piece</span></td>


                                                <!-- price -->
                                                <td class="valign-middle text-center"><span
                                                        class="text-black-f">7,000</span></td>

                                            </tr>
                                            <!-- end table row -->




                                        </tbody>
                                    </table>



                                </div>


                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</main>
{{-- end main --}}











{{-- modals --}}

{{-- end modals --}}





@endsection
{{-- end section --}}