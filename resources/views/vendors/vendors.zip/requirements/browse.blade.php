@extends('layouts.vendor')



{{-- section --}}
@section('content')



{{-- banner --}}
<div class="tg-innerpagebanner">
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                <div class="tg-pagetitle">
                    <a href="{{ route('vendor.home') }}" class="home-button-custom">
                        <i class="fa fa-arrow-circle-left"></i>Home</a>
                </div>
                <ol class="tg-breadcrumb">
                    <li><a href="#">Home</a></li>
                    <li class="tg-active">Opportunities</li>
                </ol>
            </div>
        </div>
    </div>
</div>
{{-- end banner --}}









{{-- main --}}
<main id="tg-main" class="tg-main tg-haslayout custom-connect-wrapper" style="background-color: black;">
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-10 col-md-push-1 col-lg-8 col-lg-push-2">
                <div class="tg-sectionhead">
                    <div class="tg-sectiontitle mb-1">
                        <h2>Connent with new Customers</h2>
                    </div>
                    <div class="tg-description">
                        <h5 class="text-warning">Browse Requirements</h5>
                    </div>
                </div>
            </div>
            <div id="tg-twocolumns" class="tg-twocolumns">
                <div class="col-xs-12 col-sm-7 col-md-8 col-lg-9 pull-right">
                    <div class="row">
                        <div id="tg-content" class="tg-content">
                            <div class="tg-joblisting">
                                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-9">

                                    <div class="tg-sortfilters">

                                        <div class="tg-sortfilter custom-tg-sortfilter tg-sortby">
                                            <span>Sort By:</span>
                                            <div class="tg-select">
                                                <select>
                                                    <option>Top Rated</option>
                                                    <option>Top Seller</option>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="tg-sortfilter custom-tg-sortfilter tg-arrange">
                                            <span>Arrange:</span>
                                            <div class="tg-select">
                                                <select>
                                                    <option>des</option>
                                                    <option>Asc</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="tg-sortfilter custom-tg-sortfilter tg-show">
                                            <span>Show:</span>
                                            <div class="tg-select">
                                                <select>
                                                    <option>12</option>
                                                    <option>24</option>
                                                    <option>all</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>



                                {{-- switch button --}}
                                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3 text-right">

                                    <a href="{{ route('vendor.auctions.browse') }}" class="btn btn-success">See Auctions<i
                                            class="fa fa-refresh ml-3"></i></a>
                                </div>


                                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                    <table class="tg-tablejoblidting custom-browse-table">
                                        <tbody>
                                            <tr>
                                                <td style="width: 339px;">

                                                    <div class="tg-contentbox">

                                                        <div class="tg-title">
                                                            <h3><a class="quotation-name" href="#">Develop landing
                                                                    page</a></h3>
                                                        </div>
                                                        <span>By:
                                                            <a target="_blank" class="quotation-company"
                                                                href="{{ route('vendor.companies.profile', [1]) }}">Future Group & Company</a>
                                                        </span>

                                                    </div>
                                                </td>
                                                <td><span>28 July 2021</span></td>

                                                <td><span>4 Items </span></td>
                                                <td><span><a class="tg-btn" href="javascript:void(0);" type="submit"
                                                            data-toggle="modal" data-target=".tg-categoryModal">View
                                                            Details</a>
                                                </td>


                                            </tr>

                                            <tr>
                                                <td style="width: 339px;">

                                                    <div class="tg-contentbox">

                                                        <div class="tg-title">
                                                            <h3><a class="quotation-name" href="#">Develop Portfolio
                                                                    website </a></h3>
                                                        </div>
                                                        <span>By:
                                                            <a target="_blank" class="quotation-company"
                                                                href="{{ route('vendor.companies.profile', [1]) }}">Bright Company</a>
                                                        </span>

                                                    </div>
                                                </td>
                                                <td><span>25 July 2021</span></td>

                                                <td><span>1 Items </span></td>
                                                <td><span><a href="javascript:void(0);" class="tg-btn" type="submit"
                                                            data-toggle="modal" data-target=".tg-categoryModal">View
                                                            Details</a>
                                                    </span></td>
                                            </tr>

                                            <tr>
                                                <td style="width: 339px;">

                                                    <div class="tg-contentbox">

                                                        <div class="tg-title">
                                                            <h3><a class="quotation-name" href="#">Develop landing
                                                                    page</a></h3>
                                                        </div>
                                                        <span>By:
                                                            <a target="_blank" class="quotation-company"
                                                                href="{{ route('vendor.companies.profile', [1]) }}">Truth Company</a>
                                                        </span>

                                                    </div>
                                                </td>
                                                <td><span>22 July 2021</span></td>

                                                <td><span>3 Items </span></td>
                                                <td><span><a href="javascript:void(0);" class="tg-btn" type="submit"
                                                            data-toggle="modal" data-target=".tg-categoryModal">View
                                                            Details</a>
                                                    </span></td>
                                            </tr>
      

                                        </tbody>
                                    </table>
                                </div>
                                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                    <nav class="tg-pagination">
                                        <ul>
                                            <li class="tg-prevpage"><a href="#"><i class="fa fa-angle-left"></i></a>
                                            </li>
                                            <li><a href="#">1</a></li>
                                            <li><a href="#">2</a></li>
                                            <li><a href="#">3</a></li>
                                            <li><a href="#">4</a></li>
                                            <li class="tg-active"><a href="#">5</a></li>
                                            <li>...</li>
                                            <li><a href="#">10</a></li>
                                            <li class="tg-nextpage"><a href="#"><i class="fa fa-angle-right"></i></a>
                                            </li>
                                        </ul>
                                    </nav>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-5 col-md-4 col-lg-3 pull-left">
                    <aside id="tg-sidebar" class="tg-sidebar">
                        <form class="tg-themeform tg-formrefinesearch">
                            <fieldset>
                                <h4>Filter By Categories</h4>
                                <div class="tg-checkboxgroup">

                                    <div class="form-group">
                                        <span class="tg-select">
                                            <select>
                                                <option>All Catagories</option>
                                                <option>Software Development </option>
                                                <option>Legal Concelatancy</option>
                                                <option>Coaching & Training </option>
                                                <option>Design </option>
                                                <option>MArketing </option>
                                            </select>
                                        </span>
                                    </div>

                                    <!-- <a href="#" data-toggle="modal" data-target=".tg-categoryModal">View All</a> -->
                                </div>
                            </fieldset>


                            <fieldset>
                                <h4>Filter By Subcategories</h4>
                                <div class="tg-checkboxgroup">
                                    <span class="tg-checkbox">
                                        <input type="checkbox" id="all" name="fresh" value="all" checked>
                                        <label for="all">All</label>
                                    </span>
                                    <span class="tg-checkbox">
                                        <input type="checkbox" id="fresh" name="fresh" value="fresh">
                                        <label for="fresh">Web design</label>
                                    </span>
                                    <span class="tg-checkbox">
                                        <input type="checkbox" id="1years" name="fresh" value="1years">
                                        <label for="1years">Graphiv design </label>
                                    </span>
                                    <span class="tg-checkbox">
                                        <input type="checkbox" id="2years" name="fresh" value="2years">
                                        <label for="2years">Mobile App </label>
                                    </span>
                                    <span class="tg-checkbox">
                                        <input type="checkbox" id="3years" name="fresh" value="German">
                                        <label for="3years">E-commerce </label>
                                    </span>
                                    <!-- <a href="#" data-toggle="modal" data-target=".tg-categoryModal">View All</a> -->
                                </div>
                            </fieldset>


                            <fieldset>
                                <button class="tg-btn" type="submit" style="border:1px solid whitesmoke">apply</button>
                                <button class="tg-btn custom-reset-button" type="reset">reset</button>
                            </fieldset>
                        </form>
                    </aside>
                </div>
            </div>
        </div>
    </div>
</main>
{{-- end main --}}










{{-- modals --}}

{{-- quotation modal --}}
<div class="modal fade tg-categoryModal" tabindex="-1">
    <div class="modal-dialog tg-modaldialog" role="document">
        <div class="modal-content tg-modalcontent">
            <div class="tg-modalhead">
                <h2>Send Quotation </h2>
                <span class="tg-selecteditems">3 Requirements</span>
            </div>
            <div class="tg-modalbody">
                <form class="tg-themeform tg-formrefinesearch">

                    <div class="tg-columnstyle">

                        <div class="tg-column table-caption">


                            <table class="table custom-quo-table"
                                style="border: 1px solid lightgrey; margin-bottom: 20px;">
                                <tbody>

                                    <thead>


                                        <th>
                                            Name
                                        </th>

                                        <th>
                                            Category
                                        </th>

                                        <th class="text-center">
                                            Type
                                        </th>

                                        <th class="text-center" style="width: 100px;">
                                            Quantity
                                        </th>

                                        <th class="text-center" style="width: 130px;">
                                            Budget (AED)
                                        </th>



                                    </thead>
                                    <!-- tr -->
                                    <tr>


                                        <td>

                                            <div class="tg-contentbox">
                                                <!-- <a class="tg-tag tg-featuredtag" href="#"></a> -->
                                                <div class="tg-title">
                                                    <h3><a class="font-14" style="font-size:14px !important"
                                                            href="#">Landing Page Design</a></h3>
                                                </div>
                                                <span> </span>
                                            </div>
                                        </td>

                                        <!-- category / subcategory -->
                                        <td><span class="font-14" style="color:#333">Software Development > Web
                                                Design</span></td>




                                        <td class="valign-middle text-center">
                                            <button disabled="" class="btn-sm btn-warning">Service</button>
                                        </td>


                                        <!-- quantity + measuringunit -->
                                        <td class="valign-middle text-center"><span class="text-black-f font-13">1
                                                Page</span></td>

                                        <!-- Budget -->
                                        <td class="valign-middle text-center"><span class="text-black-f font-13">800 -
                                                1200</span></td>



                                    </tr>
                                    <!-- end table row -->



                                    <tr>

                                        <td>

                                            <div class="tg-contentbox">
                                                <!-- <a class="tg-tag tg-featuredtag" href="#"></a> -->
                                                <div class="tg-title">
                                                    <h3><a style="font-size:14px !important" href="#">Create and Design
                                                            Logo </a></h3>
                                                </div>
                                                <span> </span>
                                            </div>
                                        </td>
                                        <td><span class="font-14" style="color:#333"> Desing > Graphic Design </span>
                                        </td>

                                        <td class="valign-middle text-center">
                                            <button disabled="" class="btn-sm btn-warning">Service</button>
                                        </td>


                                        <!-- quantity + measuringunit -->
                                        <td class="valign-middle text-center"><span class="text-black-f font-13">1
                                                Logo</span></td>

                                        <!-- Budget -->
                                        <td class="valign-middle text-center"><span
                                                class="text-black-f font-13">-</span></td>




                                    </tr>


                                    <!-- tr -->
                                    <tr>



                                        <td>

                                            <div class="tg-contentbox">
                                                <!-- <a class="tg-tag tg-featuredtag" href="#"></a> -->
                                                <div class="tg-title">
                                                    <h3><a style="font-size:14px !important" href="#">Social Media
                                                            Posts</a></h3>
                                                </div>
                                                <span> </span>
                                            </div>
                                        </td>
                                        <td><span class="font-14" style="color:#333"> Marketing > Social Content </span>
                                        </td>

                                        <td class="valign-middle text-center">
                                            <button disabled="" class="btn-sm btn-warning">Product</button>
                                        </td>


                                        <!-- quantity + measuringunit -->
                                        <td class="valign-middle text-center"><span class="text-black-f font-13">100
                                                Post(s)</span></td>

                                        <!-- Budget -->
                                        <td class="valign-middle text-center"><span class="text-black-f font-13">400 -
                                                700</span></td>




                                    </tr>
                                    <!-- end tr -->


                                </tbody>
                            </table>


                            <div class="row align-items-end mb-0">

                                <div class="col-12 text-left">
                                    <a href="javascript:void(0);" class="btn btn-none confirm-quotation-edit"
                                        style="margin-left: 0px; background-color: indianred; border-color:indianred; color:white; padding: 8px 15px; font-weight: 500; border-radius: 5px !important">
                                        Download Attachments<i class="fa fa-download ml-2"></i>
                                    </a>
                                </div>

                            </div>

                        </div>
                    </div>

                    <div class="form-group tg-inpuicon" style="margin-top: 0px;">

                        <!-- total price  bild price -->
                        <!-- <h3 style="margin: 0px 0px 5px 0px"><i class="fa fa-circle quo-circle quo-circle-yellow"></i> Bid Price For Checked Requirements: <span class="text-warning-f">0 AED</span></h3> -->

                        <hr>

                        <!-- offer price (as whole) -->
                        <!-- <div class="row no-gutters align-items-center mb-4">
								<div class="col-xs-auto">
									
									<h3 style="margin: 0px 15px 0px 0px" style="display:inline !important;"><i class="fa fa-circle quo-circle"></i>Your Offer Price:</h3>

								</div>
								<div class="col-xs-auto">
									<span class="text-warning-f"> <input class="bidprice-input mb-0" type="number" name="bidprice" id=""></span>
									
								</div>

								
							</div> -->
                        <!-- end inner row -->


                        <div class="tg-companyfeaturebox tg-languages pt-0">
                            <div class="tg-companyfeaturetitle">

                                <h3 style="margin: 0px 0px 0px">Your Quotation</h3>

                            </div>


                            <div class="tg-dashboardservices pb-5">


                                <!-- first requirement (r) -->
                                <div class="tg-dashboardservice custom-pr-quotations">

                                    <!-- requirements check -->
                                    <div class="tg-servicetitle" style="padding:18px 20px;">
                                        <h2>
                                            <input class="" type="checkbox" name="" id="">
                                            <label class="d-inline">Landing Page Design
                                            </label>
                                        </h2>
                                    </div>





                                    <div class="tg-btntimeedit">

                                        <p style="padding: 8px 20px; margin-bottom: 0px;">
                                            <input class="d-inline" type="number" name="quantity" id="quo-quantity"
                                                style="width: 49%;" placeholder="Quantity">
                                            <input class="d-inline" type="text" name="price" id="quo-price"
                                                style="width: 49%;" placeholder="Price">
                                        </p>

                                    </div>
                                </div>
                                <!-- end first req -->








                                <!-- first requirement (r) -->
                                <div class="tg-dashboardservice custom-pr-quotations">

                                    <!-- requirements check -->
                                    <div class="tg-servicetitle" style="padding:18px 20px;">
                                        <h2>
                                            <input class="" type="checkbox" name="" id="">
                                            <label class="d-inline">Create and Design Logo
                                            </label>
                                        </h2>
                                    </div>





                                    <div class="tg-btntimeedit">

                                        <p style="padding: 8px 20px; margin-bottom: 0px;">
                                            <input class="d-inline" type="number" name="quantity" id="quo-quantity"
                                                style="width: 49%;" placeholder="Quantity">
                                            <input class="d-inline" type="text" name="price" id="quo-price"
                                                style="width: 49%;" placeholder="Price">
                                        </p>

                                    </div>
                                </div>
                                <!-- end 2nd  -->






                                <!-- first requirement (r) -->
                                <div class="tg-dashboardservice custom-pr-quotations">

                                    <!-- requirements check -->
                                    <div class="tg-servicetitle" style="padding:18px 20px;">
                                        <h2>
                                            <input class="" type="checkbox" name="" id="">
                                            <label class="d-inline">Social Media Posts
                                            </label>
                                        </h2>
                                    </div>





                                    <div class="tg-btntimeedit">

                                        <p style="padding: 8px 20px; margin-bottom: 0px;">
                                            <input class="d-inline" type="number" name="quantity" id="quo-quantity"
                                                style="width: 49%;" placeholder="Quantity">
                                            <input class="d-inline" type="text" name="price" id="quo-price"
                                                style="width: 49%;" placeholder="Price">
                                        </p>

                                    </div>
                                </div>
                                <!-- end third -->


                            </div>
                        </div>
                        <!-- end quootation -->


                        <h3 style="margin: 0px 0px 15px">Attachment</h3>

                        <input type="file" name="quot-attach" class=" attach-input" id="quot-attach">

                        <!-- <i class="lnr lnr-magnifier"></i> -->
                        <textarea name="Budget" id="" cols="30" class="form-control" rows="6"
                            placeholder="Additional Note!"></textarea>



                        <!-- hide from competitors -->
                        <span class="tg-checkbox" style="margin-top: 15px;">
                            <input type="checkbox" id="tg-hidequotation" name="business" value="Event Organizer">
                            <label for="tg-hidequotation"><span class="text-warning-f">Hide This Quotation From Other
                                    Competitors</span>
                            </label>
                        </span>



                        <div class="row w-100 no-gutters mt-4 align-items-center" style="margin-top: 65px !important">
                            <div class="col-3">
                                <!-- clarifications -->
                                <span class="tg-checkbox pb-0">
                                    <input type="checkbox" id="clarf-quo-checkbox" name="business"
                                        value="Event Organizer">
                                    <label for="clarf-quo-checkbox"><span class="text-warning-f">Send
                                            Clarification</span>
                                    </label>
                                </span>
                            </div>
                            <div class="col-9">
                                <hr class="d-inline-block w-100 my-0">
                            </div>
                        </div>



                        <!-- <i class="lnr lnr-magnifier"></i> -->
                        <textarea name="clarf" id="" cols="30" class="clarf-input clarf-items form-control mt-4 d-none"
                            rows="6" placeholder="Clarification Message"></textarea>

                        <p class="clarf-items text-left mb-0 mt-3 d-none">
                            <button class="btn btn-success" style="padding: 8px 40px;">Send</button>
                        </p>

                    </div>
                </form>
            </div>
            <div class="tg-modalfoot">
                <button class="tg-btn" type="submit">Submit</button>
                <a class="tg-btn quotation-view-req-button" href="{{ route('vendor.requirements.view', [1]) }}">View Requirement</a>

            </div>
        </div>
    </div>
</div>

{{-- end quotation modal --}}



{{-- end modals --}}


@endsection
{{-- end section --}}
