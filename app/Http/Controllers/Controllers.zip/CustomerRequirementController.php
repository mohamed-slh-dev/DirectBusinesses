<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Measuringunit;
use App\Models\Subcategory;
use App\Models\Type;
use App\Models\UserRequirement;
use App\Models\UserRequirementItem;
use Illuminate\Http\Request;

class CustomerRequirementController extends Controller
{



    // requirements posting function
    public function post()
    {


        $categories = Category::all();
        $subcategories = Subcategory::all();
        $types = Type::all();
        $measuringunits = Measuringunit::all();


        return view('customers.requirements.post', compact('categories', 'subcategories', 'types', 'measuringunits'));

    } //end requirements posting function








    // ------------------------------------------------



    // requirement create function
    public function create(Request $request)
    {


        // get info
        $title = $request->input('title');
        $desc = $request->input('desc');
        $serial = $request->input('requirement-serial');
        

        // attachments
        // upload image in 2 steps
        $attachments = time() . '-' . $request->file('attachments')->getClientOriginalName();
        $request->file('attachments')->move(public_path('assets/uploads/requirements'), $attachments);


        // add to blog table
        $requirement = new UserRequirement();
        $requirement->user_id = 1;
        $requirement->title = $title;
        $requirement->desc = $desc;
        $requirement->serial_number = $serial; //generate in page
        $requirement->attachments = $attachments;
        $requirement->status = 'on going';

        $requirement->save();


        // items
        $requirementCategory = $request->input('requirement-category');
        $requirementSubcategory = $request->input('requirement-subcategory');
        $requirementType = $request->input('requirement-type');
        $requirementName = $request->input('requirement-name');
        $requirementMeasuringunit = $request->input('requirement-measuringunit');
        $requirementQuantity = $request->input('requirement-quantity');
        $requirementDesc = $request->input('requirement-desc');
        $requirementComment = $request->input('requirement-comment');
        $requirementBudget = $request->input('requirement-budget');


        // add items
        for ($i = 0; $i < count($requirementName); $i++) {

            $item = new UserRequirementItem();
            $item->quantity = $requirementQuantity[$i];
            $item->name = $requirementName[$i];
            $item->desc = $requirementDesc[$i];
            $item->comment = $requirementComment[$i];


            $item->requirement_id = $requirement->id;
            $item->category_id = $requirementCategory[$i];
            $item->subcategory_id = $requirementSubcategory[$i];
            $item->type_id = $requirementType[$i];
            // $item->measuringunit_id = $requirementMeasuringunit[$i];



            // split budget into two
            $budgetArray = explode(' - ', $requirementBudget[$i]);

            if ($budgetArray[0] != "null") {
                
                $item->budget_from = (int)str_replace(' AED', '', $budgetArray[0]);
                $item->budget_to = (int)str_replace(' AED', '', $budgetArray[1]);

            }


            $item->save();

        } //end for loop




        // back to browse
        return redirect()->route('customer.requirements.view', [$requirement->id]);


    } //end blog create function






    // --------------------------------------------------




    // requirements view function
    public function view($id)
    {


        return view('customers.requirements.view');
    } //end requirements view function








    // --------------------------------------------------




    // requirements evaluation request function
    public function evaluation($id)
    {


        return view('customers.requirements.evaluation');
    } //end requirements evaluation request function






} //end controller