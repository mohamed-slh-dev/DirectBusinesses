<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class CustomerDealController extends Controller
{


    // browse deals function
    public function browse()
    {


        return view('customers.deals.browse');
    } //end browse deal function










    // --------------------------------------------------




    // view deal function
    public function view($id)
    {


        return view('customers.deals.view');
    } //end view deal function







    // --------------------------------------------------




    // view deal request function
    public function viewRequest($id)
    {


        return view('customers.deals.view-request');
    } //end view deal request function


} //end controller
