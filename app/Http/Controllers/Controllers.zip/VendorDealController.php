<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Measuringunit;
use App\Models\Subcategory;
use App\Models\Type;
use App\Models\UserDeal;
use App\Models\UserDealItem;
use App\Models\UserRequirementItem;
use Illuminate\Http\Request;

class VendorDealController extends Controller
{



    // post deal view function
    public function post()
    {


        $categories = Category::all();
        $subcategories = Subcategory::all();
        $types = Type::all();
        $measuringunits = Measuringunit::all();


        return view('vendors.deals.post', compact('categories', 'subcategories', 'types', 'measuringunits'));

    } //end post deal function










    // ------------------------------------------------



    // deal create function
    public function create(Request $request) {


        // get info
        $title = $request->input('title');
        $desc = $request->input('desc');
        $serial = $request->input('deal-serial');


        // attachments
        // upload image in 2 steps
        $attachments = time() . '-' . $request->file('attachments')->getClientOriginalName();
        $request->file('attachments')->move(public_path('assets/uploads/deals'), $attachments);


        // add to blog table
        $deal = new UserDeal();
        $deal->user_id = 1;
        $deal->title = $title;
        $deal->desc = $desc;
        $deal->serial_number = $serial; //generate in page
        $deal->attachments = $attachments;
        $deal->status = 'Available';
        
        $deal->save();


        // items
        $dealCategory = $request->input('deal-category');
        $dealSubcategory = $request->input('deal-subcategory');
        $dealType = $request->input('deal-type');
        $dealName = $request->input('deal-name');
        $dealMeasuringunit = $request->input('deal-measuringunit');
        $dealQuantity = $request->input('deal-quantity');
        $dealDesc = $request->input('deal-desc');
        $dealPrice = $request->input('deal-price');


        // add items
        for ($i = 0; $i < count($dealName); $i++) {

            $item = new UserDealItem();
            $item->min_quantity = $dealQuantity[$i];
            $item->name = $dealName[$i];
            $item->price = $dealPrice[$i];
            $item->desc = $dealDesc[$i];

            $item->deal_id = $deal->id;
            $item->category_id = $dealCategory[$i];
            $item->subcategory_id = $dealSubcategory[$i];
            $item->type_id = $dealType[$i];
            $item->measuringunit_id = $dealMeasuringunit[$i];


            $item->save();

        } //end for loop




        // back to browse
        return redirect()->route('vendor.deals.view', [$deal->id]);

    } //end blog create function







    // --------------------------------------------------




    // view deal function
    public function view($id)
    {


        return view('vendors.deals.view');
        
    } //end view deal function




} //end controller
