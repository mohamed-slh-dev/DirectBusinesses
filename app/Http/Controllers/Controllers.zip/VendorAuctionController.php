<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class VendorAuctionController extends Controller
{



    // auctions browse function
    public function browse()
    {


        return view('vendors.auctions.browse');
    } //end auctions browse function






    // --------------------------------------------------




    // auctions view function
    public function view($id)
    {


        return view('vendors.auctions.view');
    } //end auctions view function








    // --------------------------------------------------




    // auctions view request function
    public function viewRequest($id)
    {


        return view('vendors.auctions.view-request');
    } //end auctions view request function




} //end controller
