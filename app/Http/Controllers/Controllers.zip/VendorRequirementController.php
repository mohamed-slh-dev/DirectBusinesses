<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class VendorRequirementController extends Controller
{



    // requirements browse function
    public function browse()
    {


        return view('vendors.requirements.browse');
    } //end requirements browse function








    // --------------------------------------------------




    // requirements view function
    public function view($id)
    {


        return view('vendors.requirements.view');
    } //end requirements view function








    // --------------------------------------------------




    // requirements view request function
    public function viewRequest($id)
    {


        return view('vendors.requirements.view-request');
    } //end requirements view request function






} //end controller
