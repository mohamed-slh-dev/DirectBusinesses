<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PrescreenController extends Controller
{


    // prescreen function
    public function prescreen()
    {


        return view('prescreens.index');
        
    } //end prescreen function


} //end prescreen
